//
//  FooterView.swift
//  Gator
//
//  Created by Foundation-009 on 30/06/25.
//


import SwiftUI

struct FooterView: View {
    var body: some View {
        Text("Made by Kelompok 1 (Mic)").font(.caption).foregroundColor(.gray).frame(maxWidth: .infinity, alignment: .center).padding(.top, 10)
    }
}